package com.example.demo.model;

public enum MemberStatus {
    ACTIVE, DEACTIVATED
}