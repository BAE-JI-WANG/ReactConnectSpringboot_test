package com.example.demo.model;

public enum LendStatus {
    AVAILABLE, BURROWED
}